import Foundation

struct ChatMessage: Identifiable, Codable {
    let id: UUID
    let role: String // user / assistant
    let content: String
    let date: Date
    
    init(role: String, content: String) {
        self.id = UUID()
        self.role = role
        self.content = content
        self.date = Date()
    }
}

enum PaymentMethod: String, Codable {
    case kiCard = "ki"
    case zainCash = "zaincash"
    case qr = "qr"
    case applePay = "apple"
}

struct QIPayment: Codable {
    let id: String
    let amount: Int
    let status: String
    let payUrl: String?
}
