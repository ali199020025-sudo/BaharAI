import Foundation

class BaharAIService {
    // هنا تربط مع OpenAI أو CoreML المحلي
    func sendMessage(_ text: String) async throws -> String {
        // Mock ذكي يتكلم عربي
        let lower = text.lowercased()
        if lower.contains("برمجة") {
            return "البرمجة هي كتابة تعليمات للحاسوب. تبدأ بتحديد المشكلة، ثم تخطط الحل، ثم تكتب الكود بلغات مثل Swift أو Python. مثال: print(2+2) يطبع 4. تريد مثال عملي؟"
        }
        if lower.contains("كي كارد") || lower.contains("دفع") || lower.contains("اشتراك") {
            return "Bahar AI يدعم 4 طرق دفع عراقية:\n• كي كارد Qi - 7,500 د.ع (الأكثر انتشارا)\n• زين كاش - 7,500 د.ع\n• QR Code - امسح وادفع\n• Apple Pay - $5.99\nاختر الطريقة اللي تناسبك من الأسفل!"
        }
        if lower.contains("قصة") {
            return "كان يا ما كان في قديم الزمان، مبرمج عراقي اسمه علي، قرر يبني مساعد ذكي اسمه بحر AI ليساعد الناس بالعربي. ونجح! وهسه انت تستخدمه 🌊"
        }
        return "أهلاً! أنا بحر AI، مساعدك الذكي. أقدر أساعدك في البرمجة، الكتابة، الشرح، وحتى الدفع العراقي. شنو تريد نبدأ؟"
    }
}
