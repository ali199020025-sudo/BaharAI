import Foundation
import StoreKit

enum PaymentError: Error { case failed, cancelled }

class BaharPayService: ObservableObject {
    static let shared = BaharPayService()
    @Published var isPremium = UserDefaults.standard.bool(forKey: "isPremium")
    
    // ضع رابط سيرفرك هنا
    let baseURL = "https://bahar-pay.onrender.com" // أو الساندبوكس للتجربة
    let isSandbox = true // خليه true للتجربة بدون فلوس حقيقية
    
    func pay(method: PaymentMethod, amount: Int = 7500) async throws -> Bool {
        if isSandbox {
            // Mock نجاح بعد ثانيتين
            try await Task.sleep(nanoseconds: 2_000_000_000)
            unlockPremium()
            return true
        }
        
        // Production: اتصال بالسيرفر الموحد
        let url = URL(string: "\(baseURL)/api/payments/create")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "method": method.rawValue,
            "amount": amount,
            "plan": "pro_monthly",
            "userId": UIDevice.current.identifierForVendor?.uuidString ?? "unknown"
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, _) = try await URLSession.shared.data(for: req)
        // هنا تفتح payUrl في Safari أو WKWebView
        // بعد الدفع، الـ webhook يفعل الاشتراك
        unlockPremium()
        return true
    }
    
    func unlockPremium() {
        DispatchQueue.main.async {
            self.isPremium = true
            UserDefaults.standard.set(true, forKey: "isPremium")
        }
    }
    
    // Apple Pay / StoreKit
    func payWithApple() async throws {
        // StoreKit 2 - المنتج Pro
        // productId: com.alibahar.baharai.pro.monthly
        unlockPremium()
    }
}
