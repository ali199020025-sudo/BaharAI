import Foundation

class KiCardService {
    // Qi Gateway - للإنتاج
    func createPayment(amount: Int, orderId: String) async throws -> String {
        // في الإنتاج: POST https://api.qicard.com/v1/payments
        // مع HMAC SHA256
        // للتجربة نرجع Mock URL
        return "https://pay.qicard.com/mock/\(orderId)"
    }
    
    func generateHMAC(amount: Int, orderId: String, secret: String) -> String {
        // HMAC SHA256 باستخدام secret من Qi
        // مثال: HMAC(orderId+amount, secret)
        return "mock_hmac"
    }
}
