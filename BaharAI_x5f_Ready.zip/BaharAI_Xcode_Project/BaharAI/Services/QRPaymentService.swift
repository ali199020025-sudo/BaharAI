import UIKit
import CoreImage.CIFilterBuiltins

class QRPaymentService {
    func generateQR(from string: String) -> UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(string.utf8)
        filter.correctionLevel = "H"
        guard let output = filter.outputImage else { return nil }
        let transform = CGAffineTransform(scaleX: 10, y: 10)
        let scaled = output.transformed(by: transform)
        let context = CIContext()
        guard let cgImage = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
    
    func createQRTansaction(amount: Int) -> (id: String, image: UIImage?, url: String) {
        let id = UUID().uuidString
        let url = "https://bahar.ai/pay/\(id)?amount=\(amount)"
        let img = generateQR(from: url)
        return (id, img, url)
    }
}
