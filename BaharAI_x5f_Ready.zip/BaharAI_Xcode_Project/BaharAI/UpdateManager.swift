
import Foundation
import SwiftUI

struct AppVersion: Codable {
    let version: String
    let build: Int
    let changelog: [String]
    let mandatory: Bool
    let ipaUrl: String?
    let releaseNotes: String
}

class UpdateManager: ObservableObject {
    static let currentVersion = "1.1.0"
    static let currentBuild = 3
    
    @Published var latestVersion: AppVersion?
    @Published var isChecking = false
    @Published var updateAvailable = false
    @Published var showUpdateSheet = false
    @Published var downloadProgress: Double = 0
    @Published var isDownloading = false
    
    func checkForUpdates() {
        isChecking = true
        
        // Simulate API call to https://api.bahar.ai/version.json
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            // Mock latest version - in production fetch from server
            let mock = AppVersion(
                version: "1.1.0",
                build: 3,
                changelog: [
                    "✨ إضافة نظام تحديث داخل التطبيق",
                    "🎨 تحسين لوغو AB الأصلي - علي بهار العبودي",
                    "💳 دعم كي كارد وزين كاش محسن",
                    "⚡ تحسينات أداء وإصلاحات"
                ],
                mandatory: false,
                ipaUrl: "https://github.com/alibaharpash/BaharAI/releases/latest/download/BaharAI.ipa",
                releaseNotes: "تحديث مهم - ننصح بالتحديث"
            )
            
            self.latestVersion = mock
            self.isChecking = false
            
            if self.isNewerVersion(mock.version, than: UpdateManager.currentVersion) {
                self.updateAvailable = true
                self.showUpdateSheet = true
            }
        }
    }
    
    func isNewerVersion(_ new: String, than current: String) -> Bool {
        return new.compare(current, options: .numeric) == .orderedDescending
    }
    
    func startUpdate() {
        isDownloading = true
        downloadProgress = 0
        
        // Simulate download progress
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
            self.downloadProgress += 0.03
            if self.downloadProgress >= 1.0 {
                timer.invalidate()
                self.isDownloading = false
                self.downloadProgress = 1.0
                // In real app: open IPA URL or trigger App Store update
                if let urlStr = self.latestVersion?.ipaUrl, let url = URL(string: urlStr) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        UIApplication.shared.open(url)
                    }
                }
            }
        }
    }
}

// Update View
struct UpdateSheetView: View {
    @ObservedObject var updateManager: UpdateManager
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Image("AppIcon")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .shadow(radius: 10)
                    .padding(.top, 20)
                
                VStack(spacing: 8) {
                    Text("تحديث جديد متوفر! 🎉")
                        .font(.title2).bold()
                    Text("\(UpdateManager.currentVersion) → \(updateManager.latestVersion?.version ?? "")")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.blue.opacity(0.1))
                        .clipShape(Capsule())
                }
                
                if let changelog = updateManager.latestVersion?.changelog {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("ما الجديد:")
                            .font(.headline)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        ForEach(changelog, id: \.self) { item in
                            HStack(alignment: .top, spacing: 8) {
                                Text("•").foregroundColor(.blue)
                                Text(item).font(.subheadline)
                            }
                        }
                    }
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal)
                }
                
                Spacer()
                
                if updateManager.isDownloading {
                    VStack(spacing: 12) {
                        ProgressView(value: updateManager.downloadProgress)
                            .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                        Text("جاري التحميل... \(Int(updateManager.downloadProgress * 100))%")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                } else {
                    VStack(spacing: 12) {
                        Button {
                            updateManager.startUpdate()
                        } label: {
                            HStack {
                                Image(systemName: "arrow.down.circle.fill")
                                Text("تحديث الآن")
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        
                        if !(updateManager.latestVersion?.mandatory ?? false) {
                            Button("لاحقاً") { dismiss() }
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
            }
        }
    }
}
