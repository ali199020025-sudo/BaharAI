import SwiftUI

struct ContentView: View {
    @StateObject var payService = BaharPayService.shared
    @State private var messages: [ChatMessage] = []
    @State private var inputText = ""
    @State private var isTyping = false
    @State private var showPaywall = false
    @State private var showQRScanner = false
    
    let aiService = BaharAIService()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Header
                HStack {
                    Image(systemName: "waveform.path.ecg")
                        .font(.title2)
                        .foregroundStyle(LinearGradient(colors: [.cyan, .blue], startPoint: .top, endPoint: .bottom))
                    Text("Bahar AI")
                        .font(.title3.bold())
                    Spacer()
                    if payService.isPremium {
                        Label("Pro", systemImage: "star.fill")
                            .font(.caption.bold())
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Color.yellow).foregroundColor(.black).clipShape(Capsule())
                    }
                    Button { showPaywall = true } label: {
                        Image(systemName: "crown.fill").foregroundColor(.yellow)
                    }
                }.padding()
                .background(.ultraThinMaterial)
                
                // Chat
                ScrollView {
                    LazyVStack(spacing: 12) {
                        if messages.isEmpty {
                            VStack(spacing: 16) {
                                ZStack {
                                    Circle().fill(LinearGradient(colors: [.cyan, .blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing)).frame(width: 80, height: 80)
                                    Text("B").font(.system(size: 40, weight: .bold)).foregroundColor(.white)
                                }.padding(.top, 40)
                                Text("مرحبا، أنا بحر AI").font(.title2.bold())
                                Text("مساعدك الذكي من العراق").foregroundColor(.secondary)
                                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                                    ForEach(["اشرح لي البرمجة", "اكتب لي قصة", "كيف أدفع بكي كارد؟", "شنو مميزات برو؟"], id: \.self) { tip in
                                        Button { Task { await send(tip) } } label: {
                                            Text(tip).font(.caption).padding(10).frame(maxWidth: .infinity).background(Color.white.opacity(0.1)).clipShape(RoundedRectangle(cornerRadius: 12))
                                        }.tint(.white)
                                    }
                                }.padding()
                            }
                        }
                        ForEach(messages) { msg in
                            HStack {
                                if msg.role == "user" { Spacer() }
                                Text(msg.content).padding(12).background(msg.role == "user" ? LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing) : LinearGradient(colors: [Color(.systemGray5)], startPoint: .leading, endPoint: .trailing)).clipShape(RoundedRectangle(cornerRadius: 18)).foregroundColor(msg.role == "user" ? .white : .primary)
                                if msg.role == "assistant" { Spacer() }
                            }.padding(.horizontal)
                        }
                        if isTyping {
                            HStack { ProgressView().scaleEffect(0.7); Text("بحر يكتب...").font(.caption).foregroundColor(.secondary); Spacer() }.padding(.horizontal)
                        }
                    }.padding(.vertical)
                }
                
                // Input
                HStack(spacing: 8) {
                    TextField("اكتب رسالتك...", text: $inputText, axis: .vertical).padding(10).background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 20))
                    Button { Task { await send(inputText) } } label: {
                        Image(systemName: "arrow.up.circle.fill").font(.system(size: 34)).foregroundStyle(inputText.isEmpty ? Color.gray : LinearGradient(colors: [.cyan, .blue], startPoint: .top, endPoint: .bottom))
                    }.disabled(inputText.isEmpty)
                }.padding()
            }
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showPaywall) { PaywallView().environmentObject(payService) }
    }
    
    func send(_ text: String) async {
        guard !text.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        let userMsg = ChatMessage(role: "user", content: text)
        await MainActor.run { messages.append(userMsg); inputText = ""; isTyping = true }
        if !payService.isPremium && messages.filter({ $0.role == "user"}).count > 5 {
            await MainActor.run { isTyping = false; showPaywall = true }
            return
        }
        do {
            let reply = try await aiService.sendMessage(text)
            let botMsg = ChatMessage(role: "assistant", content: reply)
            await MainActor.run { messages.append(botMsg); isTyping = false }
        } catch {
            await MainActor.run { isTyping = false }
        }
    }
}

struct PaywallView: View {
    @EnvironmentObject var pay: BaharPayService
    @Environment(\.dismiss) var dismiss
    @State private var processing = false
    @State private var showSuccess = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(colors: [.cyan.opacity(0.3), .blue.opacity(0.3), .purple.opacity(0.3)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 16) {
                        Image(systemName: "crown.fill").font(.system(size: 50)).foregroundColor(.yellow).padding(.top)
                        Text("اشتراك برو").font(.largeTitle.bold())
                        Text("افتح كل الميزات").foregroundColor(.secondary)
                        VStack(alignment: .leading, spacing: 12) {
                            ForEach(["وصول غير محدود للذكاء الاصطناعي", "دعم عربي عراقي كامل", "دفع بكي كارد وزين كاش و QR", "بدون اعلانات"], id: \.self) { f in Label(f, systemImage: "checkmark.circle.fill").foregroundColor(.green) }
                        }.padding().background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 16))
                        
                        VStack(spacing: 12) {
                            Button { Task { await payMethod(.kiCard) } } label: { PayRow(icon: "creditcard.fill", title: "كي كارد Qi", subtitle: "الأكثر استخداما في العراق", price: "7,500 د.ع / شهر", color: .red, badge: "موصى به") }
                            Button { Task { await payMethod(.zainCash) } } label: { PayRow(icon: "wallet.pass.fill", title: "زين كاش", subtitle: "ادفع عبر المحفظة", price: "7,500 د.ع / شهر", color: .orange) }
                            Button { Task { await payMethod(.qr) } } label: { PayRow(icon: "qrcode", title: "دفع QR", subtitle: "امسح وادفع في المحل", price: "7,500 د.ع", color: .black) }
                            Button { Task { await payMethod(.applePay) } } label: { PayRow(icon: "applelogo", title: "Apple Pay", subtitle: "StoreKit", price: "$5.99 / شهر", color: .black) }
                        }.padding(.horizontal)
                        
                        if processing { ProgressView("جاري الدفع...") }
                        if showSuccess {
                            Label("تم التفعيل! مبروك Pro", systemImage: "checkmark.seal.fill").font(.headline).foregroundColor(.green).padding().background(.green.opacity(0.2)).clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                    }.padding()
                }
            }.navigationBarItems(trailing: Button("اغلاق") { dismiss() })
        }
    }
    
    func payMethod(_ m: PaymentMethod) async {
        processing = true
        do {
            let ok = try await pay.pay(method: m)
            if ok { showSuccess = true; try? await Task.sleep(nanoseconds: 1_000_000_000); dismiss() }
        } catch { }
        processing = false
    }
}

struct PayRow: View {
    let icon: String; let title: String; let subtitle: String; let price: String; let color: Color; var badge: String? = nil
    var body: some View {
        HStack {
            Image(systemName: icon).foregroundColor(color).font(.title3).frame(width: 40, height: 40).background(color.opacity(0.15)).clipShape(RoundedRectangle(cornerRadius: 8))
            VStack(alignment: .leading) { Text(title).font(.headline); Text(subtitle).font(.caption).foregroundColor(.secondary) }
            Spacer()
            VStack(alignment: .trailing) { Text(price).font(.subheadline.bold()); if let b = badge { Text(b).font(.caption2.bold()).padding(.horizontal, 6).padding(.vertical, 2).background(Color.yellow).foregroundColor(.black).clipShape(Capsule()) } }
        }.padding().background(Color.white).foregroundColor(.black).clipShape(RoundedRectangle(cornerRadius: 16)).shadow(radius: 2)
    }
}
