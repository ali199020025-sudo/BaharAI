# Bahar AI - by Ali Bahar Al-Aboudi
## اللوغو الأصلي AB

المشروع يستخدم لوغو علي بهار العبودي الأصلي:
- AB متداخل مع <> برمجة
- موجة + نقطة مضيئة
- تدرج سماوي أزرق

### التثبيت عبر AltStore
1. افتح BaharAI.xcodeproj
2. Product > Archive > Distribute App > Ad Hoc > Export
3. يطلع BaharAI.ipa
4. AltStore > My Apps > + > اختر IPA

### الدفع
- كي كارد Qi
- زين كاش
- QR
- Apple Pay

Bundle ID: com.alibahar.baharai
المطور: علي بهار العبودي - ALI BAHAR AL-ABOUDI
