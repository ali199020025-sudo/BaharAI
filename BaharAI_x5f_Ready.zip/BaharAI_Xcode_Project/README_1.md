# Bahar AI - Xcode Project

## تشغيل المشروع

1. افتح BaharAI.xcodeproj في Xcode 15+
2. اختر جهازك (iPhone) من الأعلى
3. اضغط Cmd+R للتشغيل

## بناء IPA لـ AltStore

1. في Xcode: Product > Archive
2. بعد الانتهاء: Distribute App > Ad Hoc > Export
3. يطلع ملف BaharAI.ipa
4. افتح AltStore على آيفونك > My Apps > + > اختر IPA
5. التطبيق يثبت!

## الدفع

- غير BaharPayService.swift: baseURL لرابط سيرفرك
- isSandbox = true للتجربة، false للحقيقي

## Bundle ID
com.alibahar.baharai

## المطور
علي بحر - Ali Bahar
